/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\ifone                                            */
/*    Created:      Sun Feb 23 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;

// A global instance of vex::competition
vex::competition Competition;

// define your global instances of motors and other devices here


/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the cortex has been powered on and    */ 
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton( void ) {
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
  
}
//settings 
double kP = 0.00001; 
double kI = 0.0; 
double kD = 0.0; 

double turnkP = 0.00001;
double turnkI = 0.0;
double turnkD = 0.0;

double liftkP = 0.00001;
double liftkI = 0.0;
double liftkD = 0.0;

double tiltkP = 0.00001;
double tiltkI = 0.0;
double tiltkD = 0.0;

//Auton Settings
int desiredValue = 0;
int desiredTurnValue = 0;
int desiredLiftValue = 0;
int desiredTiltValue = 0;

int error; // Sensor Value - Desired Value = Position
int prevError = 0; // Position 20 milliseconds ago 
int derivitive; // Difference Between Error and Previous Error = Calculates Speed
int totalError = 0; // Total Error = Total Error + Error

int turnError; // Sensor Value - Desired Value = Position
int turnprevError = 0; // Position 20 milliseconds ago 
int turnderivitive; // Difference Between Error and Previous Error = Calculates Speed
int turntotalError = 0; // Total Error = Total Error + Error

int liftError; // Sensor Value - Desired Value = Position
int liftprevError = 0; // Position 20 milliseconds ago 
int liftderivitive; // Difference Between Error and Previous Error = Calculates Speed
int lifttotalError = 0; // Total Error = Total Error + Error

int tiltError; // Sensor Value - Desired Value = Position
int tiltprevError = 0; // Position 20 milliseconds ago 
int tiltderivitive; // Difference Between Error and Previous Error = Calculates Speed
int tilttotalError = 0; // Total Error = Total Error + Error

// variables modified for use
bool enableDrivePID = true;

bool resetDrivesensors = false;

int drivePID(){

  while(enableDrivePID){

    if(resetDrivesensors){

      resetDrivesensors = false;

      LeftMotor.setPosition(0, degrees);
      LeftMotor_2.setPosition(0, degrees);
      RightMotor.setPosition(0, degrees);
      RightMotor_2.setPosition(0, degrees);
      ArmMotor.setPosition(0, degrees);
      Tray.setPosition(0, degrees);
    }



    // Get the postion of motors
    int LeftMotorPostition = LeftMotor.position(degrees);
    int LeftMotor2Postition = LeftMotor_2.position(degrees);
    int RightMotorPostition = RightMotor.position(degrees);
    int RightMotor2Postition = RightMotor_2.position(degrees);
    int ArmMotorPostition = ArmMotor.position(degrees);
    int TilterPostition = Tray.position(degrees);
    
    ///////////////////////////////////////////////////////////////////////////////////////
    // Lateral Movement PID
    //////////////////////////////////////////////////////////////////////////////////////

    // get average Postition
    int avgPos = ((RightMotorPostition + RightMotor2Postition)/2) + ((LeftMotorPostition + LeftMotor2Postition)/2);
   
    // Potential 
    error = avgPos - desiredValue;

    // Derivitive 
    derivitive = error - prevError;

    // Intergral
    totalError += error;

    double lateralmotorPower =(error * kP + derivitive * kD + totalError * kI);
    ////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////////
    // Turning Movement PID
    //////////////////////////////
    int turndifference = ((RightMotorPostition + RightMotor2Postition)/2) - ((LeftMotorPostition + LeftMotor2Postition)/2);
   
    // Potential 
    turnError = turndifference - desiredTurnValue;

    // Derivitive 
    turnderivitive = turnError - turnprevError;

    // Intergral
    turntotalError += turnError;

    double turningmotorPower = (error * turnkP + derivitive * turnkD + totalError * turnkI);
    /////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////////
    // Lift Movement PID - Add motor commands
    //////////////////////////////
    int liftdifference = ArmMotorPostition;
   
    // Potential 
    turnError = liftdifference - desiredLiftValue;

    // Derivitive 
    turnderivitive = turnError - turnprevError;

    // Intergral
    turntotalError += turnError;

    double liftmotorPower = (error * liftkP + derivitive * liftkD + totalError * liftkI);
    /////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////////
    // Tilter Movement PID - Add motor commands`` 
    //////////////////////////////
    int tiltdifference = TilterPostition;
   
    // Potential 
    turnError = tiltdifference - desiredTiltValue;

    // Derivitive 
    turnderivitive = tiltError - tiltprevError;

    // Intergral
    tilttotalError += tiltError;

    double tiltmotorPower = (error * tiltkP + derivitive * tiltkD + totalError * tiltkI);
    /////////////////////////////////////////////////////////////////////////////////////



    LeftMotor.spin(forward, lateralmotorPower + turningmotorPower, voltageUnits::volt);
    LeftMotor_2.spin(forward, lateralmotorPower + turningmotorPower, voltageUnits::volt);
    RightMotor.spin(forward, lateralmotorPower - turningmotorPower, voltageUnits::volt);
    RightMotor_2.spin(forward, lateralmotorPower - turningmotorPower, voltageUnits::volt);
    ArmMotor.spin(reverse, liftmotorPower, voltageUnits::volt);
    Tray.spin(forward ,tiltmotorPower , voltageUnits::volt);

    tiltprevError = tiltError;
    liftprevError = liftError;
    turnprevError = turnError;
    prevError = error;
    vex::task::sleep(20);
  
  }
      return 1;

  }

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous( void ) {
 
// Starts P.I.D task 
vex::task randomname(drivePID);

// resets the encoders to 0
resetDrivesensors = true;

// Desired Value for bot to move forward
desiredValue = 300;

// Desired Value for bot to turn 
desiredTurnValue = 600;

// Desired Value for Lift to Raise
desiredLiftValue = 150;

// Desired Value for Tray to extend
desiredTiltValue = 100;

// sleep for 100 milliseconds
vex::task::sleep(100);

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol( void ) {

 while(true) {
   
        enableDrivePID = false;

   
        if (Controller1.ButtonB.pressing()) {
          
          LeftMotor.spin(vex::directionType::fwd, (Controller1.Axis3.position() + Controller1.Axis4.position())/2, vex::velocityUnits::pct);// (Axis3+Axis4)/2
          RightMotor.spin(vex::directionType::fwd, (Controller1.Axis3.position() - Controller1.Axis4.position())/2, vex::velocityUnits::pct);// (Axis3-Axis4)/2
          LeftMotor_2.spin(vex::directionType::fwd, (Controller1.Axis3.position() - Controller1.Axis4.position())/2, vex::velocityUnits::pct);// (Axis3-Axis4)/2
          RightMotor_2.spin(vex::directionType::fwd, (Controller1.Axis3.position() - Controller1.Axis4.position())/2, vex::velocityUnits::pct);// (Axis3-Axis4)/2

        } else {
          
          LeftMotor.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct); //(Axis3+Axis4)/2
          RightMotor.spin(vex::directionType::fwd, Controller1.Axis2.value(), vex::velocityUnits::pct);//(Axis3-Axis4)/2
          LeftMotor_2.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct); //(Axis3+Axis4)/2
          RightMotor_2.spin(vex::directionType::fwd, Controller1.Axis2.value(), vex::velocityUnits::pct);//(Axis3-Axis4)/2

        }

        if(Controller1.ButtonR1.pressing()) {
            
            ArmMotor.spin(directionType::fwd, 100, velocityUnits::pct);

        } else if(Controller1.ButtonL1.pressing()) {
           
            ArmMotor.spin(directionType::rev, 100, velocityUnits::pct);

        } else {
            
            ArmMotor.stop(brakeType::brake);

        }

        if(Controller1.ButtonLeft.pressing()) {
            
            Tray.spin(directionType::fwd, 50, velocityUnits::pct);

        } else if(Controller1.ButtonRight.pressing()) {
           
            Tray.spin(directionType::rev, 50, velocityUnits::pct);

        } else {
           
            Tray.stop(brakeType::brake);

        }

         if(Controller1.ButtonR2.pressing()) {
           
            Intake.spin(directionType::fwd, 100, velocityUnits::pct);
            Intake_2.spin(directionType::fwd, 100, velocityUnits::pct);

        } else if(Controller1.ButtonL2.pressing()) {
            
            Intake.spin(directionType::rev, 100, velocityUnits::pct);
            Intake_2.spin(directionType::rev, 100, velocityUnits::pct);

        } else {
            
            Intake.stop(brakeType::brake);
            Intake_2.stop(brakeType::brake);

        }
       
       vex::task::sleep(10); // was originally 20

    }
}
//
// Main will set up the competition functions and callbacks.
//
int main() {
    //Set up callbacks for autonomous and driver control periods.
    Competition.autonomous( autonomous );
    Competition.drivercontrol( usercontrol );
    
    //Run the pre-autonomous function. 
    pre_auton();
       
    //Prevent main from exiting with an infinite loop.                        
    while(1) {
      vex::task::sleep(100);//Sleep the task for a short amount of time to prevent wasted resources.
    }    
       
}